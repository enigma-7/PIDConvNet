import os, csv, six, time, json, warnings, io
#from .utils.generic_utils import Progbar
import tensorflow.keras.backend as K
#from .engine.training_utils import standardize_input_data
from collections import deque, OrderedDict, Iterable, defaultdict
try:
    import requests
except ImportError:
    requests = None


_TRAIN = 'train'
_TEST = 'test'
_PREDICT = 'predict'


from tensorflow.keras.callbacks import TensorBoard, Callback
import pandas as pd
import numpy as np

class CustomLogger(Callback):
    """Callback that streams epoch results to a csv file.
    Supports all values that can be represented as a string,
    including 1D iterables such as np.ndarray.
    # Example
    ```python
    csv_logger = CustomLogger('training.log')
    model.fit(X_train, Y_train, callbacks=[csv_logger])
    ```
    # Arguments
        filename: filename of the csv file, e.g. 'run/log.csv'.
        separator: string used to separate elements in the csv file.
        append: True: append if file exists (useful for continuing
            training). False: overwrite existing file,
    """

    def __init__(self, filename, separator=',', append=False):
        self.sep = separator
        self.filename = filename
        self.append = append
        self.writer = None
        self.keys = None
        self.append_header = True
        if six.PY2:
            self.file_flags = 'b'
            self._open_args = {}
        else:
            self.file_flags = ''
            self._open_args = {'newline': '\n'}
        super(CustomLogger, self).__init__()

    def on_train_begin(self, logs=None):
        if self.append:
            if os.path.exists(self.filename):
                with open(self.filename, 'r' + self.file_flags) as f:
                    self.append_header = not bool(len(f.readline()))
            mode = 'a'
        else:
            mode = 'w'
        self.csv_file = io.open(self.filename,
                                mode + self.file_flags,
                                **self._open_args)

    def on_epoch_begin(self, epoch, logs=None):
        self.epoch_time_start = time.time()             ##

    def on_epoch_end(self, epoch, logs=None):
        logs = logs or {}
        logs['train_time'] = time.time()-self.epoch_time_start      ##

        def handle_value(k):
            is_zero_dim_ndarray = isinstance(k, np.ndarray) and k.ndim == 0
            if isinstance(k, six.string_types):
                return k
            elif isinstance(k, Iterable) and not is_zero_dim_ndarray:
                return '"[%s]"' % (', '.join(map(str, k)))
            else:
                return k

        if self.keys is None:
            self.keys = sorted(logs.keys())

        if self.model.stop_training:
            # We set NA so that csv parsers do not fail for this last epoch.
            logs = dict([(k, logs[k] if k in logs else 'NA') for k in self.keys])

        if not self.writer:
            class CustomDialect(csv.excel):
                delimiter = self.sep
            fieldnames = ['epoch'] + self.keys
            if six.PY2:
                fieldnames = [unicode(x) for x in fieldnames]
            self.writer = csv.DictWriter(self.csv_file,
                                         fieldnames=fieldnames,
                                         dialect=CustomDialect)
            if self.append_header:
                self.writer.writeheader()

        row_dict = OrderedDict({'epoch': epoch})
        row_dict.update((key, handle_value(logs[key])) for key in self.keys)
        self.writer.writerow(row_dict)
        self.csv_file.flush()

    def on_train_end(self, logs=None):
        self.csv_file.close()
        self.writer = None

def logger_(dataname, stamp, mname):
    fname = dataname + stamp + mname
    tensorboard = TensorBoard(log_dir='logs-TB/%s'%fname, update_freq=500)
    csvlogger = CustomLogger('logs-CSV/%s'%fname)
    print("\n" + fname + "\n")
    return tensorboard, csvlogger

def import_(filenames, position = 1):
    li = []
    nm = []

    for i, filename in enumerate(filenames):
        nm.append(filename.split('_')[-position])
        df = pd.read_csv(filename, index_col=None, header=0)
        df['model_name'] = ["%s"%filename.split('_')[-position]]*df.values.shape[0]
        li.append(df)

    frame = pd.concat(li, axis=0, names=nm)
    frame = frame.set_index(['model_name', 'epoch'])
    frame.head()
    frame.sum(level='model_name').sort_values(by='train_time', inplace=True)
    return frame, nm
